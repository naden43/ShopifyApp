//
//  ProductDetailsViewModel.swift
//  ShopifyApp
//
//  Created by Salma on 11/06/2024.
//

import Foundation

class ProductDetailsViewModel {
    var selectedProduct: Product?
    
    init(selectedProduct: Product?) {
        self.selectedProduct = selectedProduct
    }
}
