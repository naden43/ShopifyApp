//
//  AllCustomerResponse.swift
//  ShopifyApp
//
//  Created by Salma on 09/06/2024.
//


import Foundation

struct AllCustomersResponse: Codable {
    var customers: [Customer]?
}


